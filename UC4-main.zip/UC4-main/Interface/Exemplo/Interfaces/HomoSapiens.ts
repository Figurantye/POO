import { HomoErectus } from "./HomoErectus";

export interface HomoSapiens extends HomoErectus{
    falar():void
    inventar():void

}


