export interface HomoErectus {
    //atributos
    nome:string
    idade:number
    //métodos
    respirar():void
    comer():void
    andar():void


}